#include <iostream>
#include "Type.hpp"

Type :: Type()
{
	m_value=0;
}
Type :: Type(int a)
{
this->m_value=a;

}



int Type::getValue()
{
 return  m_value;
}













