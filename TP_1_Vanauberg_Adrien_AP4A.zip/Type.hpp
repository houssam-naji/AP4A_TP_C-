#ifndef TYPE_H
#define TYPE_H



class Type
{



	public :
		Type();
		Type(int a);	
		int getValue();
		
		
		
	private:

		int m_value;









};


#endif
