#include <iostream>
#include "Server.hpp"
#include "Type.hpp"
#include <fstream>

using namespace std;


Server ::Server()
{
	this->m_consolActivation=true;
	this->m_logActivation=true;
}

Server ::Server(Server const& server)
{	
	this->m_consolActivation=server.m_consolActivation;
	this->m_logActivation=server.m_logActivation;
}


Server& Server::operator=(Server const& server)
{
	this->m_consolActivation=server.m_consolActivation;
	this->m_logActivation=server.m_logActivation;
	return *this;
}




void Server::operator<<(Type &type)
{
	if(this->m_consolActivation)
	{
		this->consolWrite(type);
	}

	if(this->m_logActivation)
	{

		this->fileWrite(type);
	}

}



void Server::fileWrite(Type type)
{

	ofstream flux("Sensor_data.txt", ios::app);
	if(flux)
	{
		flux << type.getValue()<< endl;


	}else{ cout <<"ERREUR: IMPOSSIBLE OPENING" << endl; }


}

void Server::consolWrite(Type type)
{
	int value(type.getValue());
	cout << value << endl;

}

void Server :: setConsol(bool switcher)
{
	this->m_consolActivation=switcher;
}
void Server :: setLog (bool switcher)
{
	this->m_logActivation=switcher;
}
