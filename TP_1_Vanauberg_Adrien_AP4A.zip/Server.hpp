#ifndef SERVER_H
#define SERVER_H

#include <iostream>
#include "Type.hpp" 


class Server
{

	public :
		Server();
		Server(Server const& server); //constructeur de copie
		Server& operator=(Server const& server);
		void operator<<(Type & type);
		void setConsol(bool switcher);
		void setLog (bool switcher);	


	private:
		bool m_consolActivation;
		bool m_logActivation;

		void print(Type pif);
		void fileWrite (Type type);//redirige vers un ficher de la valeur renvoyé par le capteur
		void consolWrite(Type type);//redirige vers la console la valeur renvoyé par le capteur
};








#endif
